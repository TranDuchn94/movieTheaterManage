package fa.training.movietheater_mockproject.model.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@AllArgsConstructor
@Getter
@ToString
public class MailerDto {
    private String email;
    private String name;
}
