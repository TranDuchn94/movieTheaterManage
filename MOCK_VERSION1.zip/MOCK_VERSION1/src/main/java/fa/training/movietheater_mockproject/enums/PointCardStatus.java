package fa.training.movietheater_mockproject.enums;

public enum PointCardStatus {
    PAYMENT, CHARGE_POINT
}
