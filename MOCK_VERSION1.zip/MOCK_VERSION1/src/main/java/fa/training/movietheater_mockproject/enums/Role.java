package fa.training.movietheater_mockproject.enums;

public enum Role {
    ADMIN, EMPLOYEE
}
