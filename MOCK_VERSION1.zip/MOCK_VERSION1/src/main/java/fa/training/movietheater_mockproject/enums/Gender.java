package fa.training.movietheater_mockproject.enums;

public enum Gender {
    MALE,
    FEMALE
}
