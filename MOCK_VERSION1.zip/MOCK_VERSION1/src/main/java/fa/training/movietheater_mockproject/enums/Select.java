package fa.training.movietheater_mockproject.enums;

public enum Select {

    SELECTED, UN_SELECTED
}
