package fa.training.movietheater_mockproject.enums;

public enum Rank {
    BRONZE, SILVER, GOLD
}
