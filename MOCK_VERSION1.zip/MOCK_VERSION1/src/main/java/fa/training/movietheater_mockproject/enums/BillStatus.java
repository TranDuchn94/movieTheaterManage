package fa.training.movietheater_mockproject.enums;

public enum BillStatus {
    PAID, UN_PAID
}
