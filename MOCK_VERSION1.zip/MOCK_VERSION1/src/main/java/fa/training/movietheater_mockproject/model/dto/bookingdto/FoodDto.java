package fa.training.movietheater_mockproject.model.dto.bookingdto;

import lombok.Data;

@Data
public class FoodDto {
    private Long foodId;

    private String foodName;

    private String foodImgURL;

    private Double foodPrice;


}
