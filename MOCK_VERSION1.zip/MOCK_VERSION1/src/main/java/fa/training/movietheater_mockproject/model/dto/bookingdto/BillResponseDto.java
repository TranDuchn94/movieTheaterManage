package fa.training.movietheater_mockproject.model.dto.bookingdto;

import lombok.Data;

@Data
public class BillResponseDto {

    private Long billId;

    private Double totalPrice;

}
