package fa.training.movietheater_mockproject.model.dto;

import lombok.Data;

@Data
public class PaymentDto {
    private Long id;

    private String name;
}
