package fa.training.movietheater_mockproject.enums;

public class AppConstant {
    public static final Integer PAGE_NUMBER = 0;
    public static final Integer SIZE = 5;

    public static final String DATE_PATTERN = "dd/MM/yyyy";
}
